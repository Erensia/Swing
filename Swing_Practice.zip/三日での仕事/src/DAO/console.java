package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import DBConnection.ConnectionUnit;
import DTO.TableDTO;

public class console {

	public static void main(String[] args) {
		ArrayList<TableDTO> list = new ArrayList<TableDTO>();
		String sql = "select * from kensyuuname";
		try {
			Connection conn = new ConnectionUnit().getConn();
			PreparedStatement pst = conn.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				String name_sei = rs.getString("氏名(姓)");
				String name_name = rs.getString("氏名(名)");
				String yuubinn = rs.getString("郵便番号");
				String email = rs.getString("Eメール");
				int age = rs.getInt("年齢");

				TableDTO dto = new TableDTO(name_sei, name_name, yuubinn, email, age);
				list.add(dto);
				System.out.println(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			new ConnectionUnit().disConn();
		}

	}

}
